// Lens Vault - Background Service Worker
console.log('[Lens Vault] Background service worker started');

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('[Lens Vault] Extension installed');
});

// Handle messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[Lens Vault] Message received:', message.type);

    if (message.type === 'FORM_DETECTED') {
        console.log('[Lens Vault] Login form detected on:', message.url);
    }

    sendResponse({ success: true });
});

console.log('[Lens Vault] Background service worker ready');
