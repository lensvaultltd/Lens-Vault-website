// Lens Vault - Content Script
console.log('[Lens Vault] Content script loaded on:', window.location.hostname);

// Detect login forms
function detectLoginForm() {
    const passwordFields = document.querySelectorAll('input[type="password"]');

    if (passwordFields.length > 0) {
        console.log('[Lens Vault] Found', passwordFields.length, 'password field(s)');

        // Notify background script
        chrome.runtime.sendMessage({
            type: 'FORM_DETECTED',
            url: window.location.hostname
        });

        return true;
    }

    return false;
}

// Run detection when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', detectLoginForm);
} else {
    detectLoginForm();
}

console.log('[Lens Vault] Content script ready');
