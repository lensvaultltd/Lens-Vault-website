// Lens Vault - Popup Script
document.getElementById('openVaultBtn').addEventListener('click', function () {
    chrome.tabs.create({ url: 'http://localhost:3000' });
});
